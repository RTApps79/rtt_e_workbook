import { Rank } from './types';

export const KEY_PROFILE = 'tribunal_profile_v3';
export const KEY_SETTINGS = 'tribunal_settings_v3';
export const KEY_STUDY_CASES = 'tribunal_study_cases_v3';
export const KEY_STATS = 'tribunal_stats_v3';

export const DEFINITIONS = {
  category: {
    intentional: 'Intentional torts involve deliberate acts (threats, unauthorized touching, restraint, defamation, privacy invasion).',
    unintentional: 'Unintentional torts involve failure to meet the standard of care (negligence/malpractice).',
    ethics: 'Ethics violations relate to professional standards (mandatory rules vs aspirational code).'
  },
  charge: {
    assault: 'Assault = threat of harmful/offensive contact that creates fear (no touching required).',
    battery: 'Battery = harmful/offensive touching or procedure without valid consent.',
    false_imprisonment: 'False imprisonment = restraining freedom of movement without legal authority/consent.',
    invasion_privacy: 'Invasion of privacy = accessing/sharing private info without need-to-know (confidentiality breach).',
    libel: 'Libel = written defamation.',
    slander: 'Slander = spoken defamation.',
    negligence: 'Negligence = breach of duty causing harm (failure to act as a prudent professional).',
    res_ipsa: 'Res ipsa loquitur = “the thing speaks for itself”; negligence inferred without expert testimony.',
    respondeat: 'Respondeat superior = employer liability for employee actions within scope of employment.',
    ethics_rules: 'ARRT Rules = mandatory requirements; violations can trigger sanctions.',
    ethics_code: 'ARRT Code = aspirational ideals guiding professionalism.'
  }
};

export const RANKS: Rank[] = [
  { min: 0, title: 'Junior Clerk' },
  { min: 20, title: 'Associate Judge' },
  { min: 50, title: 'Senior Magistrate' },
  { min: 90, title: 'Chief Justice' },
  { min: 140, title: 'Supreme Tribunal Judge' }
];

export const builtInCases = [
    {id:1,title:'The Unwilling Patient',html:`<h3>Incident Report</h3><p><strong>Plaintiff:</strong> Mrs. G. (Patient)<br><strong>Defendant:</strong> Therapist T.</p><p><strong>Facts:</strong> The patient became claustrophobic in the immobilization mask and shouted, "Stop! Get this off me!" Therapist T. replied, "If you don't stop wiggling, I am going to strap your arms down so we can finish."</p><div class="witness-box"><strong>Witness Statement:</strong> "The therapist never actually touched the patient's arms or applied straps. They just said they would."</div>`,category:'intentional',charge:'assault',verdict:'liable',explanation:'<strong>Assault</strong> is the <em>threat</em> of touching in an injurious way. Even without touching, a verbal threat creating fear of restraint can constitute civil assault.'},
    {id:2,title:'The Wrong Isocenter',html:`<h3>Medical Record Audit</h3><p><strong>Incident:</strong> Patient A.B. received 200 cGy to the T-Spine.</p><p><strong>Prescription:</strong> Prescription was for L-Spine.</p><p><strong>Detail:</strong> The therapist aligned to the wrong tattoo. They did not verify the site with the simulation images before beam on.</p><div class="witness-box"><strong>Defense:</strong> "It was an accident. I didn't mean to hurt them."</div>`,category:'unintentional',charge:'negligence',verdict:'liable',explanation:'This is <strong>Professional Negligence (Malpractice)</strong>. The therapist failed to use reasonable care (site verification) that a prudent therapist would have used.'},
    {id:3,title:'The Loose Lips',html:`<h3>Elevator Security Cam Transcript</h3><p><strong>Location:</strong> Public Elevator, Lunch Hour.</p><p><strong>Transcript:</strong><br>Therapist A: "Did you see Dr. Smith's setup today? He has no idea what he's doing. He's totally incompetent and dangerous."<br>(Other people are present in the elevator).</p><p><strong>Outcome:</strong> Dr. Smith's reputation was damaged.</p>`,category:'intentional',charge:'slander',verdict:'liable',explanation:'<strong>Slander</strong> is spoken defamation. Making false/damaging statements about professional competence in a public setting can qualify.'},
    // FIX: Escaped the apostrophe in "patient's" to "patient\'s" to prevent a syntax error.
    {id:4,title:'The Restrained Patient',html:`<h3>Patient Complaint</h3><p><strong>Scenario:</strong> An elderly patient was confused. The therapist applied masking tape across the patient's forehead and velcro straps to their wrists to keep them on the table while the therapist went to the console.</p><p><strong>Documentation:</strong> No physician order for restraints exists in the chart.</p>`,category:'intentional',charge:'false_imprisonment',verdict:'liable',explanation:'<strong>False Imprisonment</strong>. Restricting a patient\'s freedom of movement without consent or legal authority (e.g., appropriate order) is unlawful.'},
    {id:5,title:'The Falling Block',html:`<h3>Incident Report</h3><p><strong>Event:</strong> A heavy lead block fell from the accessory tray and struck the patient.</p><p><strong>Argument:</strong> The patient's lawyer argues they do not need an expert witness to prove negligence, because "blocks don't just fall unless someone was careless."</p>`,category:'unintentional',charge:'res_ipsa',verdict:'liable',explanation:'<strong>Res Ipsa Loquitur</strong> ("The thing speaks for itself"). The event is so suggestive of negligence that the burden of proof can shift.'},
    {id:6,title:'The Celebrity File',html:`<h3>IT Access Logs</h3><p><strong>User:</strong> Student Therapist J.</p><p><strong>Action:</strong> Accessed the EMR of a famous actor currently being treated in the hospital.</p><p><strong>Defense:</strong> "I didn't share the info with anyone. I was just curious."</p>`,category:'intentional',charge:'invasion_privacy',verdict:'liable',explanation:'<strong>Invasion of Privacy / Confidentiality Breach</strong>. Access without a true need-to-know is a violation even if not shared.'},
    {id:7,title:'The Exam Cheater',html:`<h3>ARRT Review Board</h3><p><strong>Subject:</strong> Therapist K.</p<p><strong>Incident:</strong> Caught using a hidden phone to photograph questions during the Registry Exam.</p><p><strong>Charge:</strong> Violation of Standard of Ethics.</p>`,category:'ethics',charge:'ethics_rules',verdict:'liable',explanation:'This violates the <strong>ARRT Rules of Ethics</strong> (mandatory). Subverting the examination process can lead to serious sanctions.'},
    {id:8,title:'The Written Insult',html:`<h3>Medical Chart Entry</h3><p><strong>Note entered by Therapist:</strong> "Patient is an alcoholic and was rude today."</p><p><strong>Fact:</strong> Patient has a gait imbalance due to brain mets, not alcohol.</p>`,category:'intentional',charge:'libel',verdict:'liable',explanation:'<strong>Libel</strong> is written defamation. Entering false, damaging statements into a medical record may qualify.'},
    {id:9,title:'The Bad Order',html:`<h3>Courtroom Testimony</h3><p><strong>Therapist:</strong> "I knew the dose looked wrong (1000 cGy for one fraction), but Dr. X told me to push the button, so I did. It's his fault."</p><p><strong>Outcome:</strong> Patient suffered severe necrosis.</p><p><strong>Question:</strong> Can the therapist be held personally responsible?</p>`,category:'unintentional',charge:'negligence',verdict:'liable',explanation:'<strong>Personal Liability</strong>: each professional is responsible for their own negligent conduct. Following a clearly unsafe order does not absolve responsibility.'},
    {id:10,title:'The Missing Signature',html:`<h3>Pre-Treatment Audit</h3><p><strong>Action:</strong> Therapist performed CT Simulation and tattooed the patient.</p><p><strong>Document:</strong> The Informed Consent form for Simulation was not signed.</p><p><strong>Patient Claim:</strong> "I didn't know I would get permanent tattoos. That's Battery."</p>`,category:'intentional',charge:'battery',verdict:'liable',explanation:'<strong>Battery</strong>. Performing a procedure (tattooing/touching) without valid consent can be battery. Informed consent should occur before the procedure.'}
] as const;

export const THEMES: Record<string, Record<string, string>> = {
  classic: {
    '--bg': '#222',
    '--wood': '#5d4037',
    '--wood-dark': '#3e2723',
    '--wood-mid': '#4e342e',
    '--gold': '#ffb300',
    '--paper': '#fdfbf7',
    '--ink': '#2c3e50',
    '--red': '#b71c1c',
    '--green': '#2e7d32',
    '--muted': '#c7b8b1',
    '--shadow': 'rgba(0,0,0,.5)',
  },
  marble: {
    '--bg': '#14171a',
    '--wood': '#e6e6e6',
    '--wood-dark': '#cfcfcf',
    '--wood-mid': '#f2f2f2',
    '--gold': '#d4af37',
    '--paper': '#ffffff',
    '--ink': '#1c1f23',
    '--red': '#b71c1c',
    '--green': '#2e7d32',
    '--muted': '#6e6e6e',
    '--shadow': 'rgba(0,0,0,.35)',
  },
  midnight: {
    '--bg': '#0b1020',
    '--wood': '#111a33',
    '--wood-dark': '#0c1328',
    '--wood-mid': '#0f1730',
    '--gold': '#7dd3fc',
    '--paper': '#0b1224',
    '--ink': '#e2e8f0',
    '--red': '#fb7185',
    '--green': '#34d399',
    '--muted': '#93a4c7',
    '--shadow': 'rgba(0,0,0,.65)',
  },
  parchment: {
    '--bg': '#1f1a14',
    '--wood': '#7a5c3a',
    '--wood-dark': '#5a3e25',
    '--wood-mid': '#6a4a2c',
    '--gold': '#f59e0b',
    '--paper': '#fbf3dd',
    '--ink': '#2a2a2a',
    '--red': '#b71c1c',
    '--green': '#2e7d32',
    '--muted': '#8b6a4a',
    '--shadow': 'rgba(0,0,0,.55)',
  },
};
