
import React from 'react';

interface ProgressBarProps {
    value: number; // 0 to 100
}

const ProgressBar: React.FC<ProgressBarProps> = ({ value }) => {
    return (
        <div className="progress-bar h-2.5 bg-black/50 w-full">
            <div 
                className="progress-fill h-full bg-[var(--gold)] transition-all duration-300 ease-out" 
                style={{ width: `${Math.max(0, Math.min(100, value))}%` }}
            ></div>
        </div>
    );
};

export default ProgressBar;
