import React, { useState, useEffect } from 'react';
import { Settings } from '../types';
import Modal from './Modal';
import Button from './Button';

interface SettingsModalProps {
    isOpen: boolean;
    onClose: () => void;
    settings: Settings;
    onSave: (newSettings: Partial<Settings>) => void;
}

const Select = (props: React.SelectHTMLAttributes<HTMLSelectElement>) => (
    <select {...props} className="w-full p-2 bg-white text-black border border-black/20 rounded-md font-sans" />
);

// FIX: Refactored the Label component props definition to use a type alias for clarity and to resolve potential typing issues.
type LabelProps = {
  children: React.ReactNode;
}
// FIX: Changed component definition to use props object directly to fix children prop error.
const Label = (props: LabelProps) => (
    <label className="font-sans text-sm font-bold block mb-1.5">{props.children}</label>
);

const SettingsModal: React.FC<SettingsModalProps> = ({ isOpen, onClose, settings, onSave }) => {
    const [currentSettings, setCurrentSettings] = useState(settings);

    useEffect(() => {
        setCurrentSettings(settings);
    }, [settings, isOpen]);
    
    const handleSave = () => {
        onSave(currentSettings);
        onClose();
    };
    
    const handleSettingChange = (key: keyof Settings, value: any) => {
      setCurrentSettings(prev => ({...prev, [key]: value}));
    };

    return (
        <Modal isOpen={isOpen} onClose={onClose} title="Courtroom Settings">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                    <Label>Visual Theme</Label>
                    <Select value={currentSettings.theme} onChange={e => handleSettingChange('theme', e.target.value)}>
                        <option value="classic">Classic Wood</option>
                        <option value="marble">Marble Hall</option>
                        <option value="midnight">Midnight Court</option>
                        <option value="parchment">Parchment</option>
                    </Select>
                </div>
                 <div>
                    <Label>Animation & Motion</Label>
                    <Select value={currentSettings.motion} onChange={e => handleSettingChange('motion', e.target.value)}>
                        <option value="full">Full Motion</option>
                        <option value="reduced">Reduced Motion</option>
                    </Select>
                </div>
                 <div>
                    <Label>Sound Effects</Label>
                    <Select value={currentSettings.sound} onChange={e => handleSettingChange('sound', e.target.value)}>
                        <option value="on">On</option>
                        <option value="off">Off</option>
                    </Select>
                </div>
                 <div>
                    <Label>Background Murmurs</Label>
                    <Select value={currentSettings.murmurs} onChange={e => handleSettingChange('murmurs', e.target.value)} disabled={currentSettings.sound === 'off'}>
                        <option value="on">On</option>
                        <option value="off">Off</option>
                    </Select>
                </div>
                 <div>
                    <Label>Narrator</Label>
                    <Select value={currentSettings.narrator} onChange={e => handleSettingChange('narrator', e.target.value)}>
                        <option value="on">On</option>
                        <option value="off">Off</option>
                    </Select>
                </div>
                 <div>
                    <Label>Narrator Speed</Label>
                    <input 
                      type="range"
                      min="0.5"
                      max="2"
                      step="0.1"
                      value={currentSettings.rate}
                      onChange={e => handleSettingChange('rate', parseFloat(e.target.value))}
                      className="w-full mt-2"
                      disabled={currentSettings.narrator === 'off'}
                    />
                    <div className="text-center font-sans text-sm">{currentSettings.rate.toFixed(1)}x</div>
                </div>
            </div>
            <div className="actions p-4 flex gap-3 justify-end -m-5 mt-5 bg-black/5">
                <Button variant="secondary" onClick={onClose} className="text-black bg-black/10">Cancel</Button>
                <Button variant="good" onClick={handleSave}>Save Settings</Button>
            </div>
        </Modal>
    );
};

export default SettingsModal;