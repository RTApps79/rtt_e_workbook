
import React, { useEffect, useMemo } from 'react';
import { Case, DifficultyParams, Profile } from '../types';
import Button from './Button';
import { computeRank } from '../utils/helpers';
import { DEFINITIONS } from '../constants';

interface VerdictOverlayProps {
    isCorrect: boolean;
    caseInfo: Case;
    difficultyParams: DifficultyParams;
    timeLeft: number;
    profile: Profile;
    attempts: number;
    onNext: () => void;
    onRetry: () => void;
    narrate: (text: string) => void;
}

const VerdictOverlay: React.FC<VerdictOverlayProps> = ({ isCorrect, caseInfo, difficultyParams, timeLeft, profile, attempts, onNext, onRetry, narrate }) => {
    const canRetry = !isCorrect && difficultyParams.level === 'easy' && attempts <= difficultyParams.retries;

    const feedback = useMemo(() => {
        const rank = computeRank(0); // This should be from stats, but not passed in here. Let's just use a placeholder
        const title = canRetry ? 'Try Again (Hint Provided)' : (isCorrect ? 'Excellent Judgment' : 'Review Legal Precedent');
        const stampText = canRetry ? 'OBJECTION' : (isCorrect ? 'VERDICT UPHELD' : 'MISTRIAL');
        const stampClass = isCorrect && !canRetry ? 'text-[var(--green)] border-[var(--green)]' : 'text-[var(--red)] border-[var(--red)]';

        let bodyHTML;
        let narrationText;

        if (canRetry) {
            const hintText = `Focus on <em>${caseInfo.charge}</em>: ${DEFINITIONS.charge[caseInfo.charge]}`;
            bodyHTML = `<p><strong>Not quite.</strong> Here’s a hint before your retry:</p><div class="mt-2 p-2.5 border-l-4 border-[var(--gold)] bg-black/5 rounded-md">${hintText}</div>`;
            narrationText = `Try again. Hint: ${DEFINITIONS.charge[caseInfo.charge]}`;
        } else {
            const baseExplanation = isCorrect ? caseInfo.explanation : `<strong>Your ruling was overturned.</strong><br><br>${caseInfo.explanation}`;
            const coaching = `Key legal principle: ${DEFINITIONS.charge[caseInfo.charge]}`;
            bodyHTML = `${baseExplanation}<hr class="my-3.5 opacity-25" />${coaching}`;
            narrationText = isCorrect ? `Verdict upheld. ${caseInfo.explanation.replace(/<[^>]*>/g, '')}` : `Mistrial. ${caseInfo.explanation.replace(/<[^>]*>/g, '')}`;
        }

        const meta = `${profile.avatar} ${profile.name} • Difficulty: ${difficultyParams.level.toUpperCase()}${difficultyParams.timeLimit > 0 ? ` • Time left: ${timeLeft}s` : ''}`;

        return { title, stampText, stampClass, bodyHTML, narrationText, meta };
    }, [canRetry, isCorrect, caseInfo, difficultyParams, timeLeft, profile]);

    useEffect(() => {
        narrate(feedback.narrationText);
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [feedback.narrationText]);


    return (
        <div className="fixed inset-0 bg-black/80 flex items-center justify-center z-20 p-4" role="dialog" aria-modal="true">
            <style>{`
                @keyframes pop {
                    0% { transform: rotate(-6deg) scale(.92); }
                    60% { transform: rotate(-6deg) scale(1.06); }
                    100% { transform: rotate(-6deg) scale(1); }
                }
                .animate-pop { animation: pop .28s ease; }
            `}</style>
            <div className="bg-white text-black p-7 rounded-lg w-full max-w-2xl shadow-xl relative">
                <div className={`verdict-stamp text-4xl font-black uppercase border-4 p-2 px-6 inline-block mb-3.5 -rotate-6 animate-pop ${feedback.stampClass}`}>
                    {feedback.stampText}
                </div>
                <h2 className="text-3xl font-bold m-0 mb-1.5">{feedback.title}</h2>
                <p className="font-sans text-sm opacity-80 mt-1">{feedback.meta}</p>
                <div className="mt-3 text-base leading-relaxed" dangerouslySetInnerHTML={{ __html: feedback.bodyHTML }} />

                <div className="flex gap-3 justify-end mt-5">
                    {canRetry && <Button variant="secondary" onClick={onRetry} className="text-black bg-black/10">Retry Case</Button>}
                    <Button variant="good" onClick={onNext}>
                        {canRetry ? 'Skip to Next' : 'Next Case'}
                    </Button>
                </div>
            </div>
        </div>
    );
};

export default VerdictOverlay;
