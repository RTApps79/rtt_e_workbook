import React, { useState, useEffect } from 'react';
import { Profile } from '../types';
import Modal from './Modal';
import Button from './Button';

interface ProfileModalProps {
    isOpen: boolean;
    onClose: () => void;
    profile: Profile;
    onSave: (newProfile: Profile) => void;
    voices: SpeechSynthesisVoice[];
}

const Input = (props: React.InputHTMLAttributes<HTMLInputElement>) => (
    <input {...props} className="w-full p-2 bg-white text-black border border-black/20 rounded-md" />
);

// FIX: Refactored the Label component props definition to use a type alias for clarity and to resolve potential typing issues.
type LabelProps = {
  children: React.ReactNode;
}
// FIX: Changed component definition to use props object directly to fix children prop error.
const Label = (props: LabelProps) => (
    <label className="font-sans text-sm font-bold block mb-1.5">{props.children}</label>
);

const ProfileModal: React.FC<ProfileModalProps> = ({ isOpen, onClose, profile, onSave, voices }) => {
    const [currentProfile, setCurrentProfile] = useState(profile);

    useEffect(() => {
        setCurrentProfile(profile);
    }, [profile, isOpen]);

    const handleSave = () => {
        onSave(currentProfile);
        onClose();
    };

    return (
        <Modal isOpen={isOpen} onClose={onClose} title="Edit Your Profile">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 font-sans">
                <div>
                    <Label>Judge Name</Label>
                    <Input 
                        value={currentProfile.name}
                        onChange={(e) => setCurrentProfile({ ...currentProfile, name: e.target.value })}
                    />
                </div>
                <div>
                    <Label>Avatar (Emoji)</Label>
                    <Input 
                        value={currentProfile.avatar}
                        onChange={(e) => setCurrentProfile({ ...currentProfile, avatar: e.target.value })}
                        maxLength={2}
                    />
                </div>
                <div className="md:col-span-2">
                    <Label>Narrator Voice</Label>
                    <select 
                        className="w-full p-2 bg-white text-black border border-black/20 rounded-md"
                        value={currentProfile.voiceURI}
                        onChange={(e) => setCurrentProfile({ ...currentProfile, voiceURI: e.target.value })}
                        disabled={voices.length === 0}
                    >
                        <option value="">System Default</option>
                        {voices.map((voice) => (
                            <option key={voice.voiceURI} value={voice.voiceURI}>
                                {voice.name} ({voice.lang})
                            </option>
                        ))}
                    </select>
                </div>
            </div>
             <div className="mt-4 p-3 border-l-4 border-[var(--gold)] bg-black/5 rounded-md text-sm">
                <strong>Tip:</strong> Your name and avatar appear on the bench and on verdict screens. The narrator voice requires browser support.
            </div>
            <div className="actions p-4 flex gap-3 justify-end -m-5 mt-5 bg-black/5">
                <Button variant="secondary" onClick={onClose} className="text-black bg-black/10">Cancel</Button>
                <Button variant="good" onClick={handleSave}>Save Profile</Button>
            </div>
        </Modal>
    );
};

export default ProfileModal;