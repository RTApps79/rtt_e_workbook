
import React from 'react';
import Button from './Button';
import { Settings, DifficultyParams } from '../types';

interface TopBarProps {
    onSettingsClick: () => void;
    onStudyClick: () => void;
    onProfileClick: () => void;
    onRestartClick: () => void;
    onNarrateClick: () => void;
    onHintClick: () => void;
    onSoundClick: () => void;
    settings: Settings;
    difficultyParams: DifficultyParams;
}

const TopBar: React.FC<TopBarProps> = ({ onSettingsClick, onStudyClick, onProfileClick, onRestartClick, onNarrateClick, onHintClick, onSoundClick, settings, difficultyParams }) => {
    return (
        <div className="bg-black/10 p-2.5 flex flex-wrap items-center justify-between gap-3 border-b border-black/20">
            <div className="flex gap-2.5">
                <Button onClick={onSettingsClick}>⚙️ Settings</Button>
                <Button onClick={onStudyClick}>📚 Study Mode</Button>
                <Button onClick={onProfileClick}>🪪 Profile</Button>
                <Button onClick={onRestartClick}>🔄 Restart</Button>
            </div>
            <div className="flex gap-2.5">
                <Button variant="link" onClick={onNarrateClick}>{settings.narrator === 'on' ? '🔊 Narrate' : '🔇 Narrate'}</Button>
                <Button variant="link" onClick={onHintClick} disabled={!difficultyParams.showHints} className={!difficultyParams.showHints ? 'opacity-50' : ''}>💡 Hint</Button>
                <Button variant="link" onClick={onSoundClick}>{settings.sound === 'on' ? '🔈 Sound' : '🔇 Muted'}</Button>
            </div>
        </div>
    );
};

export default TopBar;
