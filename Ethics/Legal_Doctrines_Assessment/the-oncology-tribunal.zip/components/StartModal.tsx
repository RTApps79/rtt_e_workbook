
import React from 'react';
import Modal from './Modal';
import Button from './Button';

interface StartModalProps {
    isOpen: boolean;
    onClose: () => void;
    onProfileClick: () => void;
    onSettingsClick: () => void;
}

const StartModal: React.FC<StartModalProps> = ({ isOpen, onClose, onProfileClick, onSettingsClick }) => {
    const footer = (
        <span className="font-sans opacity-80 text-sm">
            Press <strong>Esc</strong> to close this screen anytime.
        </span>
    );
    
    return (
        <Modal isOpen={isOpen} onClose={onClose} title="Welcome to The Oncology Tribunal" footer={footer} size="xl">
            <div className="font-sans text-base leading-relaxed">
                <p className="mb-4">
                    You are the presiding judge in a fast-paced tribunal of radiation oncology law & ethics. Review each case file, classify the legal category, identify the best-fitting charge, and issue a final verdict. Your performance unlocks ranks, changes difficulty, and earns you courtroom prestige.
                </p>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="p-3 border border-black/10 rounded-lg bg-black/5">
                        <div className="font-extrabold mb-1.5">How to Play</div>
                        <ol className="list-decimal list-inside space-y-1">
                            <li>Read the case facts (and witness box if present).</li>
                            <li>Select <strong>Legal Category</strong>, <strong>Specific Charge</strong>, and <strong>Final Verdict</strong>.</li>
                            <li>Click <strong>Deliver Verdict</strong> to see the tribunal’s decision.</li>
                            <li>Use <strong>Hint</strong> if available; difficulty adapts to recent accuracy.</li>
                        </ol>
                    </div>
                    <div className="p-3 border border-black/10 rounded-lg bg-black/5">
                        <div className="font-extrabold mb-1.5">Key Features</div>
                        <ul className="list-disc list-inside space-y-1">
                            <li><strong>Ranks & scoring</strong> (streak bonuses included).</li>
                            <li><strong>Narrator</strong> reads case files & feedback (toggle anytime).</li>
                            <li><strong>Study Mode</strong>: create, import, and generate cases with AI.</li>
                            <li><strong>Sound & animations</strong> (gavel, murmurs, confetti).</li>
                        </ul>
                    </div>
                </div>
                <div className="mt-4 p-3 border-l-4 border-[var(--gold)] bg-black/5 rounded-lg">
                    <div className="font-extrabold mb-1.5">Quick Tips</div>
                    <ul className="list-disc list-inside space-y-1">
                        <li>For best sound/narration, click anywhere once to allow audio playback.</li>
                        <li>Open <strong>Settings</strong> to change themes, sound, narrator, and motion.</li>
                        <li>Open <strong>Profile</strong> to set your judge name, avatar, and narration voice.</li>
                    </ul>
                </div>
                <div className="flex gap-3 mt-5 flex-wrap">
                    <Button variant="good" onClick={onClose}>Enter the Courtroom</Button>
                    <Button variant="secondary" onClick={onProfileClick} className="text-black bg-black/10">Set Profile First</Button>
                    <Button variant="secondary" onClick={onSettingsClick} className="text-black bg-black/10">Adjust Settings</Button>
                </div>
            </div>
        </Modal>
    );
};

export default StartModal;
