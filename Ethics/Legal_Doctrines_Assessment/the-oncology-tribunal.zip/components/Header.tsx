
import React from 'react';
import { Profile, Stats } from '../types';
import { computeRank } from '../utils/helpers';

interface HudPillProps {
    label: string;
    value: string | number;
}
const HudPill: React.FC<HudPillProps> = ({ label, value }) => (
    <div className="bg-white/10 border border-white/15 text-white px-3 py-1.5 rounded-full flex gap-2 items-center text-sm font-sans">
        <span className="opacity-80">{label}</span>
        <strong className="text-[var(--gold)] font-bold">{value}</strong>
    </div>
);

interface HeaderProps {
    profile: Profile;
    stats: Stats;
}

const Header: React.FC<HeaderProps> = ({ profile, stats }) => {
    const accuracy = stats.played > 0 ? Math.round((stats.correct / stats.played) * 100) : 0;
    const rank = computeRank(stats.score);

    return (
        <header className="bg-[var(--wood-dark)] text-[var(--gold)] p-5 border-b-4 border-[var(--gold)] flex flex-col sm:flex-row items-center justify-between gap-4">
            <div className="title text-center sm:text-left">
                <h1 className="text-3xl tracking-wider uppercase font-bold">The Oncology Tribunal</h1>
                <p className="font-sans text-md opacity-90">Honorable Judge {profile.name} Presiding</p>
            </div>
            <div className="hud flex gap-2.5 flex-wrap justify-center" aria-label="Performance HUD">
                <HudPill label="Rank" value={rank} />
                <HudPill label="Score" value={stats.score} />
                <HudPill label="Streak" value={stats.streak} />
                <HudPill label="Accuracy" value={`${accuracy}%`} />
            </div>
        </header>
    );
};

export default Header;
