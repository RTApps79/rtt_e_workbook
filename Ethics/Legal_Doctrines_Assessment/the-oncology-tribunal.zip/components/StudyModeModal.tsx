
import React, { useState, useCallback } from 'react';
import { StudyCaseData } from '../types';
import Modal from './Modal';
import Button from './Button';
import { generateStudyCase } from '../services/geminiService';

interface StudyModeModalProps {
    isOpen: boolean;
    onClose: () => void;
    studyCases: StudyCaseData[];
    onAddCase: (newCase: StudyCaseData) => void;
    onDeleteCase: (index: number) => void;
    onStartGame: (mode: 'study' | 'mixed') => void;
}

const newCaseDefault: StudyCaseData = {
    title: '',
    facts: '',
    witness: '',
    category: 'intentional',
    charge: 'assault',
    verdict: 'liable',
    explanation: ''
};

const StudyModeModal: React.FC<StudyModeModalProps> = ({ isOpen, onClose, studyCases, onAddCase, onDeleteCase, onStartGame }) => {
    const [view, setView] = useState<'list' | 'add'>('list');
    const [newCase, setNewCase] = useState<StudyCaseData>(newCaseDefault);
    const [aiTopic, setAiTopic] = useState('');
    const [isGenerating, setIsGenerating] = useState(false);
    const [error, setError] = useState('');

    const handleAddCase = () => {
        if (newCase.title && newCase.facts && newCase.explanation) {
            onAddCase(newCase);
            setNewCase(newCaseDefault);
            setView('list');
        } else {
            alert('Please fill in Title, Facts, and Explanation.');
        }
    };

    const handleGenerate = async () => {
        if (!aiTopic.trim()) {
            setError('Please enter a topic for the AI to generate a case.');
            return;
        }
        setIsGenerating(true);
        setError('');
        try {
            const generatedCase = await generateStudyCase(aiTopic);
            setNewCase(generatedCase);
        } catch (err: any) {
            setError(err.message || 'An unknown error occurred.');
        } finally {
            setIsGenerating(false);
        }
    };

    const renderListView = () => (
        <div>
            <div className="flex justify-between items-center mb-4">
                <h4 className="font-bold text-lg font-sans">Your Custom Cases ({studyCases.length})</h4>
                <Button variant="good" onClick={() => { setNewCase(newCaseDefault); setView('add'); }}>Add New Case</Button>
            </div>
            <div className="max-h-64 overflow-y-auto border border-black/10 rounded-md p-2 bg-black/5">
                {studyCases.length === 0 ? (
                    <p className="text-center p-4 text-gray-500 font-sans">No custom cases yet. Add one to get started!</p>
                ) : (
                    <ul className="space-y-2">
                        {studyCases.map((c, i) => (
                            <li key={i} className="flex justify-between items-center p-2 bg-white rounded-md">
                                <span className="font-sans font-semibold">{c.title}</span>
                                <Button variant="primary" onClick={() => onDeleteCase(i)} className="!p-2 !rounded-md">Delete</Button>
                            </li>
                        ))}
                    </ul>
                )}
            </div>
             <div className="actions p-4 flex gap-3 justify-end -m-5 mt-5 bg-black/5">
                <Button variant="secondary" onClick={() => onStartGame('standard')} className="text-black bg-black/10 mr-auto">Start Standard Game</Button>
                <Button variant="secondary" onClick={() => onStartGame('mixed')} className="text-black bg-black/10" disabled={studyCases.length === 0}>Start Mixed Game</Button>
                <Button variant="good" onClick={() => onStartGame('study')} disabled={studyCases.length === 0}>Start Study Game</Button>
            </div>
        </div>
    );
    
    const renderAddView = () => (
        <div>
            <div className="flex justify-between items-center mb-4">
                <h4 className="font-bold text-lg font-sans">Create New Case</h4>
                <Button variant="secondary" onClick={() => setView('list')} className="text-black bg-black/10">Back to List</Button>
            </div>
            <div className="space-y-2 max-h-[60vh] overflow-y-auto pr-2 font-sans">
                <div className="p-3 border rounded-md bg-amber-50 border-amber-200">
                    <label className="font-bold block mb-1">Generate with AI ✨</label>
                    <div className="flex gap-2">
                        <input type="text" placeholder="e.g., patient confidentiality breach" className="w-full p-2 bg-white text-black border border-black/20 rounded-md" value={aiTopic} onChange={e => setAiTopic(e.target.value)} disabled={isGenerating}/>
                        <Button variant="good" onClick={handleGenerate} disabled={isGenerating}>{isGenerating ? 'Generating...' : 'Generate'}</Button>
                    </div>
                    {error && <p className="text-red-600 text-sm mt-1">{error}</p>}
                </div>

                <label className="font-bold block">Title</label>
                <input type="text" className="w-full p-2 bg-white text-black border border-black/20 rounded-md" value={newCase.title} onChange={e => setNewCase({...newCase, title: e.target.value})} />
                
                <label className="font-bold block">Facts</label>
                <textarea className="w-full p-2 bg-white text-black border border-black/20 rounded-md" rows={3} value={newCase.facts} onChange={e => setNewCase({...newCase, facts: e.target.value})} />

                <label className="font-bold block">Witness Statement (Optional)</label>
                <input type="text" className="w-full p-2 bg-white text-black border border-black/20 rounded-md" value={newCase.witness} onChange={e => setNewCase({...newCase, witness: e.target.value})} />
                
                <div className="grid grid-cols-3 gap-2">
                    <div>
                        <label className="font-bold block">Category</label>
                        <select className="w-full p-2 bg-white text-black border border-black/20 rounded-md" value={newCase.category} onChange={e => setNewCase({...newCase, category: e.target.value as any})}>
                          <option value="intentional">Intentional Tort</option><option value="unintentional">Unintentional Tort</option><option value="ethics">Ethics</option>
                        </select>
                    </div>
                    <div>
                        <label className="font-bold block">Charge</label>
                        <select className="w-full p-2 bg-white text-black border border-black/20 rounded-md" value={newCase.charge} onChange={e => setNewCase({...newCase, charge: e.target.value as any})}>
                          <option value="assault">Assault</option><option value="battery">Battery</option><option value="false_imprisonment">False Imprisonment</option><option value="invasion_privacy">Invasion of Privacy</option><option value="libel">Libel</option><option value="slander">Slander</option><option value="negligence">Negligence</option><option value="res_ipsa">Res Ipsa Loquitur</option><option value="respondeat">Respondeat Superior</option><option value="ethics_rules">ARRT Rules</option><option value="ethics_code">ARRT Code</option>
                        </select>
                    </div>
                    <div>
                        <label className="font-bold block">Verdict</label>
                        <select className="w-full p-2 bg-white text-black border border-black/20 rounded-md" value={newCase.verdict} onChange={e => setNewCase({...newCase, verdict: e.target.value as any})}>
                          <option value="liable">Liable</option><option value="not_liable">Not Liable</option>
                        </select>
                    </div>
                </div>

                <label className="font-bold block">Explanation</label>
                <textarea className="w-full p-2 bg-white text-black border border-black/20 rounded-md" rows={3} value={newCase.explanation} onChange={e => setNewCase({...newCase, explanation: e.target.value})} />
            </div>
            <div className="actions p-4 flex gap-3 justify-end -m-5 mt-5 bg-black/5">
                <Button variant="secondary" onClick={() => setView('list')} className="text-black bg-black/10">Cancel</Button>
                <Button variant="good" onClick={handleAddCase}>Save Case</Button>
            </div>
        </div>
    );

    return (
        <Modal isOpen={isOpen} onClose={onClose} title="Study Mode" size="xl">
            {view === 'list' ? renderListView() : renderAddView()}
        </Modal>
    );
};

export default StudyModeModal;
