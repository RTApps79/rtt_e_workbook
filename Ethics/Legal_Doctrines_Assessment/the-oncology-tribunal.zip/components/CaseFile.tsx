
import React from 'react';
import { Case } from '../types';

interface CaseFileProps {
  caseInfo: Case;
  isShaking: boolean;
}

const CaseFile: React.FC<CaseFileProps> = ({ caseInfo, isShaking }) => {
  const shakeClass = isShaking ? 'animate-shake' : '';

  return (
    <div className="flex-grow-[1.6] p-6 flex justify-center items-start">
      <style>{`
        @keyframes shake {
          0% { transform: rotate(-1deg) translateX(0); }
          20% { transform: rotate(-1deg) translateX(-8px); }
          40% { transform: rotate(-1deg) translateX(8px); }
          60% { transform: rotate(-1deg) translateX(-6px); }
          80% { transform: rotate(-1deg) translateX(6px); }
          100% { transform: rotate(-1deg) translateX(0); }
        }
        .animate-shake {
          animation: shake 0.45s ease;
        }
        .case-text h3 {
          font-size: 1.1em;
          font-weight: bold;
          margin-top: 0.5rem;
          margin-bottom: 0.5rem;
        }
        .case-text p {
          margin-bottom: 1rem;
        }
        .case-text .witness-box {
          background-color: #eee;
          color: #333;
          border-left: 4px solid #333;
          padding: 10px;
          margin: 14px 0;
          font-family: ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, "Liberation Mono", "Courier New", monospace;
          font-size: .92rem;
        }
      `}</style>
      <div 
        className={`bg-[var(--paper)] text-[var(--ink)] w-full min-h-[460px] p-6 rounded-md rounded-l-sm rounded-r-lg shadow-lg shadow-[var(--shadow)] relative origin-top-left -rotate-1 ${shakeClass}`}
      >
        <div className="absolute -top-3.5 left-0 w-44 h-7 bg-[var(--paper)] rounded-t-lg px-4 flex items-center font-sans font-extrabold text-[var(--muted)] tracking-wider">
          CASE #{String(caseInfo._sid).padStart(3, '0')}
        </div>
        <div className="border-2 border-[var(--red)] text-[var(--red)] inline-block px-2.5 py-1.5 font-extrabold uppercase -rotate-12 mb-3 opacity-75 tracking-wider">
          EXHIBIT A
        </div>
        <div className="case-text text-[1.05rem] leading-relaxed">
          <h2 className="mt-1.5 mb-2.5 text-[var(--wood)] border-b-2 border-black/10 pb-2 text-2xl font-bold">
            {caseInfo.title}
          </h2>
          <div dangerouslySetInnerHTML={{ __html: caseInfo.html }} />
        </div>
      </div>
    </div>
  );
};

export default CaseFile;
