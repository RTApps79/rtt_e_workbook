
import React from 'react';
import { UserSelection, DifficultyParams, Case } from '../types';
import Button from './Button';

interface JudgmentPanelProps {
  selection: UserSelection;
  onSelectionChange: React.Dispatch<React.SetStateAction<UserSelection>>;
  onSubmit: () => void;
  difficultyParams: DifficultyParams;
  timeLeft: number;
  hint: string | null;
}

const Select: React.FC<React.SelectHTMLAttributes<HTMLSelectElement>> = (props) => (
  <select {...props} className={`w-full p-3 bg-white/5 text-white border border-white/20 font-sans text-base rounded-lg outline-none hover:bg-white/10 focus:ring-2 focus:ring-[var(--gold)] ${props.className || ''}`} />
);

const ControlLabel: React.FC<{ children: React.ReactNode }> = ({ children }) => (
  <span className="font-sans text-xs uppercase text-[var(--gold)] mb-1.5 block tracking-widest">{children}</span>
);

const JudgmentPanel: React.FC<JudgmentPanelProps> = ({ selection, onSelectionChange, onSubmit, difficultyParams, timeLeft, hint }) => {

  const handleSelectChange = (field: keyof UserSelection) => (e: React.ChangeEvent<HTMLSelectElement>) => {
    onSelectionChange(prev => ({ ...prev, [field]: e.target.value as any }));
  };

  const coachMessage = () => {
    const { level, points, retries, timeLimit, showHints } = difficultyParams;
    let msg = `<strong>Coach:</strong> Difficulty is <strong>${level.toUpperCase()}</strong>. Points: <strong>${points}</strong>. `;
    if (retries > 0) msg += `Retries: <strong>${retries}</strong>. `;
    if (timeLimit > 0) msg += `Time: <strong>${timeLimit}s</strong> (remaining: <strong>${timeLeft}s</strong>). `;
    msg += showHints ? 'Hints: <strong>Enabled</strong>.' : 'Hints: <strong>Limited</strong>.';
    return msg;
  }
  
  return (
    <div className="flex-grow bg-[var(--wood-dark)] p-6 border-t-2 lg:border-t-0 lg:border-l-2 border-black/25 text-white flex flex-col gap-4">
      <div>
        <ControlLabel>1. Legal Category</ControlLabel>
        <Select value={selection.category} onChange={handleSelectChange('category')}>
          <option value="">-- Select Category --</option>
          <option value="intentional">Civil Law: Intentional Tort</option>
          <option value="unintentional">Civil Law: Unintentional Tort (Negligence)</option>
          <option value="ethics">Ethical Standard Violation</option>
        </Select>
      </div>
      <div>
        <ControlLabel>2. Specific Charge</ControlLabel>
        <Select value={selection.charge} onChange={handleSelectChange('charge')}>
          <option value="">-- Select Charge --</option>
          <option value="assault">Assault</option>
          <option value="battery">Battery</option>
          <option value="false_imprisonment">False Imprisonment</option>
          <option value="invasion_privacy">Invasion of Privacy</option>
          <option value="libel">Libel</option>
          <option value="slander">Slander</option>
          <option value="negligence">General Negligence</option>
          <option value="res_ipsa">Res Ipsa Loquitur</option>
          <option value="respondeat">Respondeat Superior</option>
          <option value="ethics_rules">Violation: ARRT Rules (Mandatory)</option>
          <option value="ethics_code">Violation: ARRT Code (Aspirational)</option>
        </Select>
      </div>
      <div>
        <ControlLabel>3. Final Verdict</ControlLabel>
        <Select value={selection.verdict} onChange={handleSelectChange('verdict')}>
          <option value="">-- Select Ruling --</option>
          <option value="liable">Liable / Guilty</option>
          <option value="not_liable">Not Liable / Dismissed</option>
        </Select>
      </div>

      <div className="bg-white/5 border border-white/15 p-3 rounded-lg font-sans text-sm leading-relaxed text-white min-h-[80px]" aria-live="polite" dangerouslySetInnerHTML={{ __html: hint || coachMessage() }} />
      
      <Button variant="primary" onClick={onSubmit} className="mt-auto">
        Deliver Verdict
      </Button>
    </div>
  );
};

export default JudgmentPanel;
