
import React from 'react';
import { Stats, Profile } from '../types';
import { computeRank } from '../utils/helpers';
import Button from './Button';

interface EndScreenProps {
    stats: Stats;
    profile: Profile;
    onNewGame: () => void;
}

const EndScreen: React.FC<EndScreenProps> = ({ stats, profile, onNewGame }) => {
    const accuracy = stats.played > 0 ? Math.round((stats.correct / stats.played) * 100) : 0;
    const rank = computeRank(stats.score);

    const handleExport = () => {
        const date = new Date().toLocaleString();
        const content = `
=================================
 THE ONCOLOGY TRIBUNAL - RESULTS
=================================

Judge: ${profile.name} (${profile.avatar})
Final Rank: ${rank}
Exported on: ${date}

--- SESSION STATS ---
Final Score: ${stats.score}
Accuracy: ${accuracy}% (${stats.correct} / ${stats.played} cases correct)
Best Streak: ${stats.bestStreak}

Thank you for playing.
    `;

        const blob = new Blob([content.trim()], { type: 'text/plain;charset=utf-8' });
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = 'Oncology_Tribunal_Results.txt';
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
        URL.revokeObjectURL(url);
    };

    return (
        <div className="w-full max-w-4xl bg-[var(--wood)] border-8 border-[var(--wood-dark)] rounded-lg shadow-2xl shadow-[var(--shadow)] overflow-hidden">
            <div className="bench-header bg-[var(--wood-dark)] text-[var(--gold)] p-5 border-b-4 border-[var(--gold)] text-center">
                <div className="title">
                    <h1 className="text-3xl tracking-wider uppercase font-bold">Court Adjourned</h1>
                    <p className="font-sans text-lg opacity-90 mt-1">
                        {profile.avatar} {profile.name} • Final Rank: <strong>{rank}</strong>
                    </p>
                </div>
            </div>
            <div className="p-10 text-center text-white font-sans">
                <h2 className="text-4xl font-bold mb-3">All Cases Heard.</h2>
                <div className="text-xl opacity-90 space-x-6">
                    <span>Score: <strong>{stats.score}</strong></span>
                    <span>Accuracy: <strong>{accuracy}%</strong></span>
                    <span>Best Streak: <strong>{stats.bestStreak || stats.streak}</strong></span>
                </div>
                <div className="mt-8 flex gap-3 justify-center">
                    <Button variant="secondary" onClick={handleExport} className="text-black bg-black/10">
                        Export Results
                    </Button>
                    <Button variant="good" onClick={onNewGame}>
                        New Session
                    </Button>
                </div>
            </div>
        </div>
    );
};

export default EndScreen;
