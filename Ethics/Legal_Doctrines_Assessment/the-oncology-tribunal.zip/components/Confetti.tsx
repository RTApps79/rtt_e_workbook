
import React, { useRef, useEffect } from 'react';

const Confetti: React.FC = () => {
    const canvasRef = useRef<HTMLCanvasElement>(null);
    const containerRef = useRef<HTMLDivElement | null>(null);
    const animationFrameId = useRef<number>();
    const particles = useRef<any[]>([]);

    useEffect(() => {
        const canvas = canvasRef.current;
        if (!canvas) return;

        const ctx = canvas.getContext('2d');
        if (!ctx) return;
        
        containerRef.current = canvas.parentElement as HTMLDivElement;

        const resizeCanvas = () => {
            if (containerRef.current) {
                canvas.width = containerRef.current.clientWidth;
                canvas.height = containerRef.current.clientHeight;
            }
        };

        const burstConfetti = () => {
            if (document.body.dataset.motion === 'reduced') return;

            const colors = ['#fbbf24', '#34d399', '#60a5fa', '#fb7185', '#a78bfa'];
            const n = 140;
            const cx = canvas.width * 0.7;
            const cy = 70;
            const newParticles = [];
            for (let i = 0; i < n; i++) {
                newParticles.push({
                    x: cx,
                    y: cy,
                    vx: (Math.random() * 2 - 1) * 6,
                    vy: (Math.random() * -1) * 9 - 2,
                    g: 0.22 + Math.random() * 0.12,
                    r: 2 + Math.random() * 4,
                    c: colors[Math.floor(Math.random() * colors.length)],
                    a: 1,
                });
            }
            particles.current = newParticles;
        };
        
        const confettiLoop = () => {
            ctx.clearRect(0, 0, canvas.width, canvas.height);
            particles.current = particles.current.filter(p => p.a > 0.02);

            for (const p of particles.current) {
                p.vy += p.g;
                p.x += p.vx;
                p.y += p.vy;
                p.a *= 0.985;
                ctx.globalAlpha = p.a;
                ctx.fillStyle = p.c;
                ctx.beginPath();
                ctx.arc(p.x, p.y, p.r, 0, Math.PI * 2);
                ctx.fill();
            }
            ctx.globalAlpha = 1;
            
            if (particles.current.length > 0) {
              animationFrameId.current = requestAnimationFrame(confettiLoop);
            }
        };

        resizeCanvas();
        burstConfetti();
        if (particles.current.length > 0) {
          animationFrameId.current = requestAnimationFrame(confettiLoop);
        }

        window.addEventListener('resize', resizeCanvas);

        return () => {
            if (animationFrameId.current) {
              cancelAnimationFrame(animationFrameId.current);
            }
            window.removeEventListener('resize', resizeCanvas);
        };
    }, []);

    return <canvas ref={canvasRef} className="absolute inset-0 pointer-events-none z-30" />;
};

export default Confetti;
