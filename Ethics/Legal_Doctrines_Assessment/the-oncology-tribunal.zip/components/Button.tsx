
import React from 'react';

interface ButtonProps extends React.ButtonHTMLAttributes<HTMLButtonElement> {
  variant?: 'primary' | 'secondary' | 'good' | 'link';
  children: React.ReactNode;
  className?: string;
}

const Button: React.FC<ButtonProps> = ({ variant = 'secondary', children, className = '', ...props }) => {
  const baseClasses = 'px-3.5 py-3 rounded-lg cursor-pointer font-bold font-sans uppercase tracking-wider transition-transform transform active:translate-y-0.5 disabled:opacity-50 disabled:cursor-not-allowed';

  const variantClasses = {
    primary: 'bg-[var(--red)] text-white shadow-[0_4px_0_rgba(127,0,0,.85)]',
    secondary: 'bg-white/10 border border-white/20 text-white hover:bg-white/20',
    good: 'bg-[var(--green)] text-white',
    link: 'bg-transparent border border-dashed border-white/30 text-white hover:bg-white/10',
  };

  return (
    <button className={`${baseClasses} ${variantClasses[variant]} ${className}`} {...props}>
      {children}
    </button>
  );
};

export default Button;
