
import React, { useEffect } from 'react';

interface ModalProps {
    isOpen: boolean;
    onClose: () => void;
    title: string;
    children: React.ReactNode;
    footer?: React.ReactNode;
    size?: 'md' | 'lg' | 'xl';
}

const Modal: React.FC<ModalProps> = ({ isOpen, onClose, title, children, footer, size = 'lg' }) => {
    useEffect(() => {
        const handleEsc = (event: KeyboardEvent) => {
            if (event.key === 'Escape') {
                onClose();
            }
        };
        if (isOpen) {
            window.addEventListener('keydown', handleEsc);
        }
        return () => {
            window.removeEventListener('keydown', handleEsc);
        };
    }, [isOpen, onClose]);

    if (!isOpen) return null;

    const sizeClasses = {
        md: 'max-w-md',
        lg: 'max-w-2xl',
        xl: 'max-w-4xl'
    };

    return (
        <div 
            className="fixed inset-0 bg-black/70 flex items-center justify-center z-50 p-4 animate-fade-in"
            onClick={onClose}
            role="dialog"
            aria-modal="true"
        >
             <style>{`
                @keyframes fade-in {
                    from { opacity: 0; }
                    to { opacity: 1; }
                }
                .animate-fade-in {
                    animation: fade-in 0.2s ease-out;
                }
             `}</style>
            <div 
                className={`modal bg-[var(--paper)] text-[var(--ink)] w-full ${sizeClasses[size]} rounded-xl shadow-2xl shadow-[var(--shadow)] overflow-hidden flex flex-col`}
                onClick={(e) => e.stopPropagation()}
            >
                <header className="bg-[var(--wood-dark)] text-[var(--gold)] px-4 py-3 flex justify-between items-center font-sans">
                    <h3 className="uppercase font-bold tracking-wider text-lg">{title}</h3>
                    <button onClick={onClose} className="text-2xl text-white/50 hover:text-white">&times;</button>
                </header>
                <div className="content p-5 overflow-y-auto">
                    {children}
                </div>
                {footer && (
                    <div className="actions p-4 flex gap-3 justify-end bg-black/5">
                        {footer}
                    </div>
                )}
            </div>
        </div>
    );
};

export default Modal;
