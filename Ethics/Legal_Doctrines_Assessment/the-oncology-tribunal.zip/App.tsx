
import React, { useState, useEffect, useCallback } from 'react';
import { GameState, Case } from './types';
import { useGame } from './hooks/useGame';
import { useAudio } from './hooks/useAudio';
import { useSpeech } from './hooks/useSpeech';
import { THEMES } from './constants';
import Header from './components/Header';
import TopBar from './components/TopBar';
import ProgressBar from './components/ProgressBar';
import CaseFile from './components/CaseFile';
import JudgmentPanel from './components/JudgmentPanel';
import VerdictOverlay from './components/VerdictOverlay';
import StartModal from './components/StartModal';
import SettingsModal from './components/SettingsModal';
import ProfileModal from './components/ProfileModal';
import StudyModeModal from './components/StudyModeModal';
import Confetti from './components/Confetti';
import EndScreen from './components/EndScreen';

export default function App() {
  const {
    gameState,
    profile,
    settings,
    stats,
    deck,
    currentCase,
    difficultyParams,
    timeLeft,
    isCorrect,
    attempts,
    userSelection,
    setUserSelection,
    submitVerdict,
    nextCase,
    retryCase,
    startNewGame,
    updateProfile,
    updateSettings,
    addStudyCase,
    deleteStudyCase,
    getHint,
    hint,
  } = useGame();

  const [isStartModalOpen, setIsStartModalOpen] = useState(true);
  const [isSettingsModalOpen, setIsSettingsModalOpen] = useState(false);
  const [isProfileModalOpen, setIsProfileModalOpen] = useState(false);
  const [isStudyModalOpen, setIsStudyModalOpen] = useState(false);
  const [showConfetti, setShowConfetti] = useState(false);

  const { playGavel, toggleMurmurs } = useAudio(settings);
  const { speak, cancelSpeech, voices } = useSpeech();
  
  useEffect(() => {
    const root = document.documentElement;
    const theme = THEMES[settings.theme] || THEMES.classic;
    Object.entries(theme).forEach(([key, value]) => {
      root.style.setProperty(key, value);
    });
    document.body.dataset.motion = settings.motion;
    toggleMurmurs();
  }, [settings, toggleMurmurs]);

  const handleVerdict = () => {
    if (!userSelection.category || !userSelection.charge || !userSelection.verdict) {
      alert('Judge, you must complete all fields before issuing a verdict.');
      return;
    }
    submitVerdict();
  };
  
  const handleNextCase = useCallback(() => {
    setShowConfetti(false);
    nextCase();
  }, [nextCase]);

  useEffect(() => {
    if (gameState === GameState.VERDICT_SHOWN) {
      playGavel();
      if (isCorrect) {
          if ((stats.streak + 1) % 3 === 0 && stats.streak > 0) {
            setShowConfetti(true);
          }
      }
    }
  }, [gameState, isCorrect, playGavel, stats.streak]);
  
  const narrate = useCallback((text: string) => {
    if (settings.narrator === 'on') {
      speak(text, settings.rate, profile.voiceURI);
    }
  }, [settings.narrator, settings.rate, profile.voiceURI, speak]);

  useEffect(() => {
    if (currentCase && gameState === GameState.PLAYING) {
      const caseTextForNarration = `Case ${currentCase._sid}. ${currentCase.title}. ${currentCase.text}`;
      narrate(caseTextForNarration);
    }
  }, [currentCase, gameState, narrate]);

  const onNewGame = (mode: 'standard' | 'study' | 'mixed') => {
    startNewGame(mode);
    setIsStudyModalOpen(false);
  }

  const handleRestart = () => {
    if (window.confirm('Are you sure you want to restart? Your current streak will be reset.')) {
      startNewGame('standard'); // Or current mode if we track it
    }
  }

  if (!currentCase && gameState === GameState.ENDED) {
    return (
        <div className="bg-[var(--bg)] text-[var(--ink)] min-h-screen p-2 sm:p-5 flex flex-col items-center justify-center font-serif">
            <EndScreen stats={stats} profile={profile} onNewGame={() => startNewGame('standard')} />
        </div>
    );
  }
  
  if (!currentCase) {
    return <div className="bg-gray-900 text-white min-h-screen flex items-center justify-center">Loading...</div>;
  }

  return (
    <div className="bg-[var(--bg)] text-[var(--ink)] min-h-screen p-2 sm:p-5 flex flex-col items-center font-serif">
        <div className="court-container w-full max-w-6xl bg-[var(--wood)] border-8 border-[var(--wood-dark)] rounded-lg shadow-2xl shadow-[var(--shadow)] overflow-hidden relative">
            {showConfetti && <Confetti />}
            
            <Header profile={profile} stats={stats} />

            <TopBar 
              onSettingsClick={() => setIsSettingsModalOpen(true)}
              onStudyClick={() => setIsStudyModalOpen(true)}
              onProfileClick={() => setIsProfileModalOpen(true)}
              onRestartClick={handleRestart}
              onNarrateClick={() => {
                const newSetting = settings.narrator === 'on' ? 'off' : 'on';
                if (newSetting === 'off') cancelSpeech();
                updateSettings({ narrator: newSetting });
              }}
              onHintClick={getHint}
              onSoundClick={() => updateSettings({ sound: settings.sound === 'on' ? 'off' : 'on' })}
              settings={settings}
              difficultyParams={difficultyParams}
            />

            <ProgressBar value={(deck.completed / deck.total) * 100} />

            <div className="bench-body flex flex-col lg:flex-row bg-[var(--wood-mid)] min-h-[560px]">
                <CaseFile caseInfo={currentCase} isShaking={gameState === GameState.VERDICT_SHOWN && !isCorrect} />
                <JudgmentPanel 
                    selection={userSelection}
                    onSelectionChange={setUserSelection}
                    onSubmit={handleVerdict}
                    difficultyParams={difficultyParams}
                    timeLeft={timeLeft}
                    hint={hint}
                />
            </div>
        </div>

        {gameState === GameState.VERDICT_SHOWN && (
            <VerdictOverlay
                isCorrect={isCorrect}
                caseInfo={currentCase}
                difficultyParams={difficultyParams}
                timeLeft={timeLeft}
                profile={profile}
                attempts={attempts}
                onNext={handleNextCase}
                onRetry={retryCase}
                narrate={narrate}
            />
        )}

        <StartModal 
          isOpen={isStartModalOpen}
          onClose={() => setIsStartModalOpen(false)}
          onProfileClick={() => { setIsStartModalOpen(false); setIsProfileModalOpen(true); }}
          onSettingsClick={() => { setIsStartModalOpen(false); setIsSettingsModalOpen(true); }}
        />
        
        <SettingsModal 
          isOpen={isSettingsModalOpen}
          onClose={() => setIsSettingsModalOpen(false)}
          settings={settings}
          onSave={updateSettings}
        />

        <ProfileModal
          isOpen={isProfileModalOpen}
          onClose={() => setIsProfileModalOpen(false)}
          profile={profile}
          onSave={updateProfile}
          voices={voices}
        />
        
        <StudyModeModal
          isOpen={isStudyModalOpen}
          onClose={() => setIsStudyModalOpen(false)}
          studyCases={deck.studyCases}
          onAddCase={addStudyCase}
          onDeleteCase={deleteStudyCase}
          onStartGame={onNewGame}
        />
    </div>
  );
}
