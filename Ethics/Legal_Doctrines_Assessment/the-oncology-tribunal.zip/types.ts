
export interface Case {
    id: number;
    _sid: number;
    isStudy?: boolean;
    title: string;
    html: string;
    text: string;
    category: 'intentional' | 'unintentional' | 'ethics';
    charge: 'assault' | 'battery' | 'false_imprisonment' | 'invasion_privacy' | 'libel' | 'slander' | 'negligence' | 'res_ipsa' | 'respondeat' | 'ethics_rules' | 'ethics_code';
    verdict: 'liable' | 'not_liable';
    explanation: string;
}

export interface StudyCaseData {
    title: string;
    facts: string;
    witness?: string;
    category: Case['category'];
    charge: Case['charge'];
    verdict: Case['verdict'];
    explanation: string;
}

export interface Profile {
    name: string;
    avatar: string;
    voiceURI: string;
}

export interface Settings {
    theme: 'classic' | 'marble' | 'midnight' | 'parchment';
    motion: 'full' | 'reduced';
    sound: 'on' | 'off';
    murmurs: 'on' | 'off';
    narrator: 'on' | 'off';
    rate: number;
}

export interface Stats {
    played: number;
    correct: number;
    streak: number;
    score: number;
    bestStreak: number;
    recent: boolean[];
}

export interface Rank {
    min: number;
    title: string;
}

export interface DifficultyParams {
    level: 'easy' | 'normal' | 'hard';
    points: number;
    retries: number;
    showHints: boolean;
    timeLimit: number;
}

export interface UserSelection {
    category: Case['category'] | '';
    charge: Case['charge'] | '';
    verdict: Case['verdict'] | '';
}

export enum GameState {
    LOADING,
    START_MODAL,
    PLAYING,
    VERDICT_SHOWN,
    ENDED,
}
