
import { GoogleGenAI, Type } from "@google/genai";
import { StudyCaseData } from "../types";

const API_KEY = process.env.API_KEY;

if (!API_KEY) {
  console.warn("API_KEY environment variable not set. Gemini features will be disabled.");
}

const ai = new GoogleGenAI({ apiKey: API_KEY });

const caseSchema = {
  type: Type.OBJECT,
  properties: {
    title: {
      type: Type.STRING,
      description: "A short, memorable title for the case, like 'The Miscalibrated Linac'.",
    },
    facts: {
      type: Type.STRING,
      description: "A paragraph describing the core facts of the scenario. Be specific and plausible for a radiation oncology setting.",
    },
    witness: {
      type: Type.STRING,
      description: "An optional, brief witness statement or defense argument that adds a twist or clarifies a point. Can be an empty string if not applicable.",
    },
    category: {
      type: Type.STRING,
      description: "The legal or ethical category of the case.",
      enum: ['intentional', 'unintentional', 'ethics'],
    },
    charge: {
      type: Type.STRING,
      description: "The most specific charge that fits the facts.",
      enum: ['assault', 'battery', 'false_imprisonment', 'invasion_privacy', 'libel', 'slander', 'negligence', 'res_ipsa', 'respondeat', 'ethics_rules', 'ethics_code'],
    },
    verdict: {
      type: Type.STRING,
      description: "The correct verdict.",
      enum: ['liable', 'not_liable'],
    },
    explanation: {
      type: Type.STRING,
      description: "A clear, concise explanation of why the charge and verdict are correct, referencing the legal or ethical principle involved. Use <strong> tags for emphasis on the key term.",
    },
  },
  required: ['title', 'facts', 'category', 'charge', 'verdict', 'explanation'],
};


export const generateStudyCase = async (topic: string): Promise<StudyCaseData> => {
  if (!API_KEY) {
    throw new Error("API key is not configured.");
  }

  const prompt = `Generate a new case for 'The Oncology Tribunal' game. The case should be a realistic legal or ethical scenario in a radiation oncology department. The topic is: "${topic}". The case must be solvable using the provided categories and charges. Ensure the explanation clearly justifies the verdict.`;

  try {
    const response = await ai.models.generateContent({
      model: "gemini-3-flash-preview",
      contents: prompt,
      config: {
        responseMimeType: "application/json",
        responseSchema: caseSchema,
        temperature: 0.8,
        systemInstruction: "You are a creative expert in medical law and ethics, specializing in radiation oncology. Your task is to create compelling, educational case studies for a learning game. The JSON output must strictly adhere to the provided schema.",
      },
    });

    const jsonText = response.text.trim();
    const generatedCase = JSON.parse(jsonText) as StudyCaseData;
    
    // Basic validation
    if (!generatedCase.title || !generatedCase.facts || !generatedCase.category || !generatedCase.charge || !generatedCase.verdict || !generatedCase.explanation) {
        throw new Error("Generated case is missing required fields.");
    }

    return generatedCase;

  } catch (error) {
    console.error("Error generating study case with Gemini:", error);
    throw new Error("Failed to generate a case. The AI may be experiencing issues. Please try again later.");
  }
};
