import { useState, useEffect, useCallback, useMemo } from 'react';
import { useLocalStorage } from './useLocalStorage';
import { Case, Profile, Settings, Stats, GameState, UserSelection, DifficultyParams, StudyCaseData } from '../types';
import { builtInCases, RANKS, DEFINITIONS, KEY_PROFILE, KEY_SETTINGS, KEY_STATS, KEY_STUDY_CASES } from '../constants';
import { stripHtml, shuffle, normalizeStudyCase, computeRank } from '../utils/helpers';

const defaultProfile: Profile = { name: 'Judge [You]', avatar: '⚖️', voiceURI: '' };
const defaultSettings: Settings = { theme: 'classic', motion: 'full', sound: 'on', murmurs: 'on', narrator: 'on', rate: 1.0 };
const defaultStats: Stats = { played: 0, correct: 0, streak: 0, score: 0, bestStreak: 0, recent: [] };

export const useGame = () => {
    const [profile, setProfile] = useLocalStorage<Profile>(KEY_PROFILE, defaultProfile);
    const [settings, setSettings] = useLocalStorage<Settings>(KEY_SETTINGS, defaultSettings);
    const [stats, setStats] = useLocalStorage<Stats>(KEY_STATS, defaultStats);
    const [studyCases, setStudyCases] = useLocalStorage<StudyCaseData[]>(KEY_STUDY_CASES, []);

    const [gameState, setGameState] = useState<GameState>(GameState.LOADING);
    const [deck, setDeck] = useState<{ all: Case[], total: number, completed: number, studyCases: StudyCaseData[] }>({ all: [], total: 0, completed: 0, studyCases:[] });
    const [currentIndex, setCurrentIndex] = useState(0);
    const [attempts, setAttempts] = useState(0);
    const [userSelection, setUserSelection] = useState<UserSelection>({ category: '', charge: '', verdict: '' });
    const [isCorrect, setIsCorrect] = useState(false);
    const [hint, setHint] = useState<string | null>(null);

    const difficultyParams: DifficultyParams = useMemo(() => {
        const n = stats.recent.length;
        const acc = n > 0 ? stats.recent.filter(Boolean).length / n : 0;
        if (n < 4) return { level: 'normal', points: 10, retries: 0, showHints: true, timeLimit: 60 };
        if (acc < 0.6) return { level: 'easy', points: 8, retries: 1, showHints: true, timeLimit: 0 };
        if (acc > 0.85) return { level: 'hard', points: 12, retries: 0, showHints: false, timeLimit: 45 };
        return { level: 'normal', points: 10, retries: 0, showHints: true, timeLimit: 60 };
    }, [stats.recent]);

    const [timeLeft, setTimeLeft] = useState(difficultyParams.timeLimit);

    const buildDeck = useCallback((mode: 'standard' | 'study' | 'mixed') => {
        // FIX: Added _sid: 0 to satisfy the Case type, which requires the _sid property.
        const normalizedBuiltInCases = builtInCases.map(c => ({...c, _sid: 0, text: stripHtml(c.html)}));
        const normalizedStudyCases = studyCases.map((c, i) => normalizeStudyCase(c, i));
        
        let arr: Case[] = [];
        if (mode === 'standard') arr = [...normalizedBuiltInCases];
        if (mode === 'study') arr = [...normalizedStudyCases];
        if (mode === 'mixed') arr = [...normalizedBuiltInCases, ...normalizedStudyCases];
        
        const shuffled = shuffle(arr).map((c, i) => ({ ...c, _sid: i + 1 }));
        setDeck({ all: shuffled, total: shuffled.length, completed: 0, studyCases });
        setCurrentIndex(0);
        return shuffled.length > 0;
    }, [studyCases]);

    const startNewGame = useCallback((mode: 'standard' | 'study' | 'mixed') => {
        const hasCases = buildDeck(mode);
        if (hasCases) {
            setGameState(GameState.PLAYING);
            setStats(s => ({ ...s, streak: 0 }));
            setTimeLeft(difficultyParams.timeLimit);
        } else {
            alert('No cases available for this mode. Add some cases in Study Mode to begin.');
            setGameState(GameState.ENDED);
        }
    }, [buildDeck, difficultyParams.timeLimit]);
    
    useEffect(() => {
        startNewGame('standard');
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, []);

    const currentCase = useMemo(() => deck.all[currentIndex], [deck.all, currentIndex]);

    useEffect(() => {
        let timer: number | null = null;
        if (gameState === GameState.PLAYING && difficultyParams.timeLimit > 0) {
            timer = window.setInterval(() => {
                setTimeLeft(prev => {
                    if (prev <= 1) {
                        clearInterval(timer!);
                        setGameState(GameState.VERDICT_SHOWN);
                        setIsCorrect(false);
                        setStats(s => ({ ...s, played: s.played + 1, streak: 0, recent: [...s.recent, false].slice(-8) }));
                        return 0;
                    }
                    return prev - 1;
                });
            }, 1000);
        }
        return () => {
            if (timer) clearInterval(timer);
        };
    }, [gameState, difficultyParams.timeLimit, setStats]);

    const submitVerdict = useCallback(() => {
        if (!currentCase) return;
        
        const correct = userSelection.category === currentCase.category &&
                        userSelection.charge === currentCase.charge &&
                        userSelection.verdict === currentCase.verdict;
        
        setIsCorrect(correct);
        setAttempts(prev => prev + 1);

        if (correct) {
            const newStreak = stats.streak + 1;
            const streakBonus = newStreak % 3 === 0 ? 5 : 0;
            setStats(s => ({
                ...s,
                played: s.played + 1,
                correct: s.correct + 1,
                streak: newStreak,
                bestStreak: Math.max(s.bestStreak, newStreak),
                score: s.score + difficultyParams.points + streakBonus,
                recent: [...s.recent, true].slice(-8),
            }));
        } else {
            const canRetry = difficultyParams.level === 'easy' && attempts < difficultyParams.retries;
            if (!canRetry) {
                setStats(s => ({
                    ...s,
                    played: s.played + 1,
                    streak: 0,
                    recent: [...s.recent, false].slice(-8),
                }));
            }
        }
        setGameState(GameState.VERDICT_SHOWN);
    }, [currentCase, userSelection, stats, difficultyParams, attempts, setStats]);

    const resetForNextCase = useCallback(() => {
        setUserSelection({ category: '', charge: '', verdict: '' });
        setAttempts(0);
        setIsCorrect(false);
        setHint(null);
        setTimeLeft(difficultyParams.timeLimit);
    }, [difficultyParams.timeLimit]);
    
    const nextCase = useCallback(() => {
        if (currentIndex + 1 >= deck.total) {
            setGameState(GameState.ENDED);
        } else {
            setCurrentIndex(i => i + 1);
            setDeck(d => ({ ...d, completed: d.completed + 1 }));
            resetForNextCase();
            setGameState(GameState.PLAYING);
        }
    }, [currentIndex, deck.total, resetForNextCase]);

    const retryCase = useCallback(() => {
        setGameState(GameState.PLAYING);
        setTimeLeft(difficultyParams.timeLimit);
    }, [difficultyParams.timeLimit]);
    
    const getHint = useCallback(() => {
        if (!currentCase || !difficultyParams.showHints) {
            alert('Hints are limited at your current difficulty.');
            return;
        }
        const hintText = `<strong>Hint Pack</strong><br>• Category cue: ${DEFINITIONS.category[currentCase.category]}<br>• Charge cue: ${DEFINITIONS.charge[currentCase.charge]}`;
        setHint(hintText);
    }, [currentCase, difficultyParams.showHints]);

    const addStudyCase = useCallback((newCase: StudyCaseData) => {
      setStudyCases(prev => [...prev, newCase]);
      setDeck(d => ({...d, studyCases: [...d.studyCases, newCase]}));
    }, [setStudyCases]);

    const deleteStudyCase = useCallback((index: number) => {
      const updatedCases = [...studyCases];
      updatedCases.splice(index, 1);
      setStudyCases(updatedCases);
      setDeck(d => ({...d, studyCases: updatedCases}));
    }, [studyCases, setStudyCases]);

    const updateSettings = useCallback((newSettings: Partial<Settings>) => {
        setSettings(prev => ({ ...prev, ...newSettings }));
    }, [setSettings]);


    return {
        gameState,
        profile,
        settings,
        stats,
        deck: { ...deck, completed: currentIndex },
        currentCase,
        difficultyParams,
        timeLeft,
        isCorrect,
        attempts,
        userSelection,
        hint,
        setUserSelection,
        updateProfile: setProfile,
        updateSettings,
        submitVerdict,
        nextCase,
        retryCase,
        startNewGame,
        addStudyCase,
        deleteStudyCase,
        getHint,
    };
};
