
import { useRef, useCallback, useEffect } from 'react';
import { Settings } from '../types';

let audioCtx: AudioContext | null = null;

const ensureAudioContext = () => {
    if (!audioCtx) {
        audioCtx = new (window.AudioContext || (window as any).webkitAudioContext)();
    }
};

export const useAudio = (settings: Settings) => {
    const murmurNodeRef = useRef<AudioBufferSourceNode | null>(null);

    const playGavel = useCallback(() => {
        if (settings.sound !== 'on') return;
        ensureAudioContext();
        if(!audioCtx) return;

        const t = audioCtx.currentTime;
        
        const osc1 = audioCtx.createOscillator();
        const gain1 = audioCtx.createGain();
        osc1.type = 'sine';
        osc1.frequency.setValueAtTime(120, t);
        osc1.frequency.exponentialRampToValueAtTime(55, t + 0.09);
        gain1.gain.setValueAtTime(0.0001, t);
        gain1.gain.exponentialRampToValueAtTime(0.6, t + 0.01);
        gain1.gain.exponentialRampToValueAtTime(0.0001, t + 0.14);
        osc1.connect(gain1).connect(audioCtx.destination);
        
        const osc2 = audioCtx.createOscillator();
        const gain2 = audioCtx.createGain();
        osc2.type = 'square';
        osc2.frequency.setValueAtTime(900, t);
        gain2.gain.setValueAtTime(0.0001, t);
        gain2.gain.exponentialRampToValueAtTime(0.25, t + 0.002);
        gain2.gain.exponentialRampToValueAtTime(0.0001, t + 0.03);
        osc2.connect(gain2).connect(audioCtx.destination);
        
        osc1.start(t);
        osc2.start(t);
        osc1.stop(t + 0.16);
        osc2.stop(t + 0.04);
    }, [settings.sound]);

    const startMurmurs = useCallback(() => {
        if (murmurNodeRef.current || !audioCtx) return;
        
        const bufferSize = 2 * audioCtx.sampleRate;
        const noiseBuffer = audioCtx.createBuffer(1, bufferSize, audioCtx.sampleRate);
        const out = noiseBuffer.getChannelData(0);
        let last = 0;
        for (let i = 0; i < bufferSize; i++) {
            const white = Math.random() * 2 - 1;
            out[i] = (last + (0.02 * white)) / 1.02;
            last = out[i];
            out[i] *= 3.5;
        }
        
        const noise = audioCtx.createBufferSource();
        noise.buffer = noiseBuffer;
        noise.loop = true;
        
        const filter = audioCtx.createBiquadFilter();
        filter.type = 'lowpass';
        filter.frequency.value = 450;
        
        const gain = audioCtx.createGain();
        gain.gain.value = 0.03;
        
        noise.connect(filter).connect(gain).connect(audioCtx.destination);
        noise.start();
        murmurNodeRef.current = noise;
    }, []);

    const stopMurmurs = useCallback(() => {
        if (murmurNodeRef.current) {
            try {
                murmurNodeRef.current.stop();
            } catch (e) {
                // Ignore errors if already stopped
            }
            murmurNodeRef.current = null;
        }
    }, []);

    const toggleMurmurs = useCallback(() => {
        if (settings.sound === 'on' && settings.murmurs === 'on') {
            ensureAudioContext();
            startMurmurs();
        } else {
            stopMurmurs();
        }
    }, [settings.sound, settings.murmurs, startMurmurs, stopMurmurs]);
    
    // Initial audio context activation
    useEffect(() => {
      const initAudio = () => {
        ensureAudioContext();
        window.removeEventListener('pointerdown', initAudio);
      };
      window.addEventListener('pointerdown', initAudio, { once: true });
      return () => window.removeEventListener('pointerdown', initAudio);
    }, []);

    return { playGavel, toggleMurmurs };
};
