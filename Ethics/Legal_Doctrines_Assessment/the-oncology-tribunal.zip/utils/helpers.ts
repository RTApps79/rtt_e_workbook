
import { Case, Rank, StudyCaseData } from '../types';
import { RANKS } from '../constants';

export const stripHtml = (html: string): string => {
    const tmp = document.createElement('div');
    tmp.innerHTML = html;
    return (tmp.textContent || tmp.innerText || '').replace(/\s+/g, ' ').trim();
};

export const shuffle = <T,>(array: T[]): T[] => {
    const newArray = [...array];
    for (let i = newArray.length - 1; i > 0; i--) {
        const j = Math.floor(Math.random() * (i + 1));
        [newArray[i], newArray[j]] = [newArray[j], newArray[i]];
    }
    return newArray;
};

export const computeRank = (score: number): string => {
    let currentRank = RANKS[0].title;
    for (const rank of RANKS) {
        if (score >= rank.min) {
            currentRank = rank.title;
        }
    }
    return currentRank;
};

const nl2br = (s: string) => (s || '').replace(/\n/g, '<br>');
const htmlEscape = (s: string) => (s || '').replace(/[&<>"']/g, (c) => ({
    "&": "&amp;",
    "<": "&lt;",
    ">": "&gt;",
    "\"": "&quot;",
    "'": "&#039;"
}[c] as string));

export const normalizeStudyCase = (studyCase: StudyCaseData, index: number): Case => {
    const html = `<h3>Study Case File</h3><p>${nl2br(htmlEscape(studyCase.facts))}</p>${studyCase.witness ? `<div class="witness-box"><strong>Witness Statement:</strong> ${nl2br(htmlEscape(studyCase.witness))}</div>` : ''}`;
    return {
        id: 1000 + index,
        _sid: 0, // Will be assigned later
        isStudy: true,
        title: studyCase.title || `Study Case ${index + 1}`,
        html: html,
        text: stripHtml(html),
        category: studyCase.category,
        charge: studyCase.charge,
        verdict: studyCase.verdict,
        explanation: studyCase.explanation ? nl2br(htmlEscape(studyCase.explanation)) : 'No explanation provided.',
    };
};
